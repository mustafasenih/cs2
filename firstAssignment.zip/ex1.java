public class AddTwoNumbers {

    public static void main(String[] args) {

        int num1 = 27, num2 = 4, sum;
        sum = num1 + num2;

        System.out.println("Sum of these numbers: "+sum);
    }
}
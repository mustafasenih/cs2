public class Main {
    public static void main (String [] args)
    {
        int number;
        int square;

        System.out.println("Number\tSquare\tCube");

        for (number=1; number<5; number++);
        {
            square = number * number;
            System.out.println(number+"\t"+square);
        }
    }

}